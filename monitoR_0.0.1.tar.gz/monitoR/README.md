
<!-- README.md is generated from README.Rmd. Please edit that file -->

# monitoR

<!-- badges: start -->
<!-- badges: end -->

The goal of monitoR is to …

## Installation

You can install the development version of monitoR from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("jonotuke/monitoR")
```

## Example
